// Square configuration for frontend
const isDevelopment = process.env.NODE_ENV !== 'production';

export const squareApplicationId = isDevelopment 
  ? 'sandbox-sq0idb-b3G3QhqMv8dmZkEJnG10kw'
  : 'sq0idp-C-wqKe8QpQAHwg3YtLziEw';

export const squareEnvironment = isDevelopment ? 'sandbox' : 'production';

// Simple Square payment handler for tokenization
export interface SquarePaymentToken {
  token: string;
  details: any;
}

export interface SquarePaymentResult {
  success: boolean;
  paymentId?: string;
  error?: string;
}